CREATE TABLE IF NOT EXISTS LegoSet (
  id   INTEGER IDENTITY PRIMARY KEY,
  name VARCHAR(100)
);
CREATE TABLE IF NOT EXISTS manual (
  id      INTEGER IDENTITY PRIMARY KEY,
  LegoSet INTEGER,
  author  CHAR(100),
  text    VARCHAR(1000)
);
CREATE TABLE IF NOT EXISTS Model (
  name        VARCHAR(100),
  description CLOB,
  legoset     INTEGER
);
