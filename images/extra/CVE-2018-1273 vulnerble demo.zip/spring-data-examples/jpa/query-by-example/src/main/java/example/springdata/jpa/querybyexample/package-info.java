/**
 * Sample showing Query-by-Example related features of Spring Data JPA.
 *
 * @author Mark Paluch
 */
package example.springdata.jpa.querybyexample;
