/**
 * Package showing usage of Spring Data abstractions for special (advanced) MongoDB operations.
 */
package example.springdata.mongodb.advanced;

