/**
 * Package showing conversion features.
 */
package example.springdata.cassandra.convert;
