/**
 * Package showing Java 8 features.
 */
package example.springdata.cassandra.java8;
